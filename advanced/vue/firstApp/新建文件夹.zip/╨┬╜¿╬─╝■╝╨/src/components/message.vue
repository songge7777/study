<template>
  <div>
    message
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style scoped>

</style>