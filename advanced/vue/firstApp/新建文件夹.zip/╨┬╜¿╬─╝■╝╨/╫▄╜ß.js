/*
  1、项目构建 初始化 
    vue init webpack firstapp
  2、配置 .eslintignore 不开启检查
  3、安装第三方库
    cnpm install -S axios
  4、element-ui
    http://element-cn.eleme.io/#/zh-CN/component/installation
    引入样式
    import 'element-ui/lib/theme-chalk/index.css';
    按需引入看文档
  5、element-ui
      NavMenu 导航菜单

*/