<template>
  <div>
    酒水
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style scoped>

</style>