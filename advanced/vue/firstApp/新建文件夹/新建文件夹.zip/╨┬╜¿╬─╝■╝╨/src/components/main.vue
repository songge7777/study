<template>
  <div>
     我要点菜
  </div>
</template>

<script>
  export default {
    mounted() {
      console.log(this.$route)
    },
  }
</script>

<style scoped>

</style>