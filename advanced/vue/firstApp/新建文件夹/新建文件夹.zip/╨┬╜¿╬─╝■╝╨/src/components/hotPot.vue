<template>
  <div>
    火锅
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style scoped>

</style>